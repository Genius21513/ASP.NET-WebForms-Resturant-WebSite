﻿CREATE TABLE [dbo].[MethodPay]
(
	[Id] INT NOT NULL PRIMARY KEY,
	[Description] VARCHAR(200) NOT NULL
)
