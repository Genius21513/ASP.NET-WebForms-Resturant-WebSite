﻿using WebApplication.Components;

namespace WebApplication
{
    public partial class About : BasePage
    {
        
    }
}