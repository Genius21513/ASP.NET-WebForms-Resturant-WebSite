﻿namespace WebApplication.Business
{
    /// <summary>
    /// Dashboard Business 
    /// </summary>
    public class DashboardBusiness
    {
                
    }
}
