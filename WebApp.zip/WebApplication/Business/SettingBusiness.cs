﻿namespace WebApplication.Business
{
    /// <summary>
    /// Setting Business
    /// </summary>
    public class SettingBusiness
    {
    }
}
