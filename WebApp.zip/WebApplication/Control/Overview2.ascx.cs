﻿using System.Web.UI;
namespace WebApplication.Control
{
    public partial class Overview2 : UserControl
    {
        public Overview2()
        {
        }
    }
}