﻿using System.Web.UI;

namespace WebApplication.Control
{
    public partial class TopProducts  : UserControl
    {
        public TopProducts()
        {
            
        }
    }
}
