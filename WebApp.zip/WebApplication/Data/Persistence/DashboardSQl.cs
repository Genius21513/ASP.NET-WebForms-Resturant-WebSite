﻿namespace WebApplication.Data.Persistence
{
    /// <summary>
    /// Web session
    /// </summary>
    public class DashboardSQl
    {       
        public string Get()
        {
            string sql = "";

            return sql;
        }
    }
}